# Aetherium Nexus Native

Projeto básico para começar com Babylon.js Native + C++ usando o NDK.